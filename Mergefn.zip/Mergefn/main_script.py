# main_script.py
import sys
import os
sys.path.append(os.path.abspath("C:\\Users\\ASUS\\Desktop\\Mergefn\\immigration"))
from immigration.merger import load_and_clean_data

input_folder = "C:/Users/ASUS/Desktop/Mergefn/"
final_df = load_and_clean_data(input_folder)

# Now you can use final_df as you like
print(final_df.head())
final_df.to_excel("cleaned_data.xlsx", index=False)
