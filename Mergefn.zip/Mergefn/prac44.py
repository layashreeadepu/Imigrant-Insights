l=[2,3,42,1,2,3,3,4]
l2=list(set(l))
print(l2)
print(l[2])
k='devesh'
print(k.upper())
print(k.capitalize())
print(k.title())

s='SHEtty'
print(s[0].lower()+s[1:])
l3=[i*i for i in l]
print(l3)

ct=len(l)-len(l2)
print(ct)
